
import { useEffect, useRef, useState } from 'react';
import { gemini, encode, decode, decodeAudioData } from '../services/geminiService';
import { Mic, MicOff, X, Sparkles, Volume2 } from 'lucide-react';

interface Props {
  onClose: () => void;
  lang: 'de' | 'ka';
}

export const LiveTutor: React.FC<Props> = ({ onClose, lang }) => {
  const [active, setActive] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [status, setStatus] = useState('Connecting to Mentor...');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  // Using a promise-based reference to avoid stale closures in event handlers
  const sessionPromiseRef = useRef<Promise<any> | null>(null);

  useEffect(() => {
    const init = async () => {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = gemini.connectLiveTutor({
        onAudio: async (base64) => {
          if (!audioContextRef.current) return;
          setIsSpeaking(true);
          const data = decode(base64);
          const buffer = await decodeAudioData(data, audioContextRef.current, 24000, 1);
          
          nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioContextRef.current.currentTime);
          const source = audioContextRef.current.createBufferSource();
          source.buffer = buffer;
          source.connect(audioContextRef.current.destination);
          source.onended = () => {
            sourcesRef.current.delete(source);
            if (sourcesRef.current.size === 0) setIsSpeaking(false);
          };
          source.start(nextStartTimeRef.current);
          nextStartTimeRef.current += buffer.duration;
          sourcesRef.current.add(source);
        },
        onInterrupted: () => {
          sourcesRef.current.forEach(s => s.stop());
          sourcesRef.current.clear();
          nextStartTimeRef.current = 0;
          setIsSpeaking(false);
        }
      });

      sessionPromiseRef.current = sessionPromise;
      await sessionPromise;
      setActive(true);
      setStatus('Mentor is listening...');

      // Input audio processing
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const source = inputCtx.createMediaStreamSource(stream);
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      
      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        const int16 = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          int16[i] = inputData[i] * 32768;
        }
        const pcmBase64 = encode(new Uint8Array(int16.buffer));
        // Use the promise pattern to ensure the latest session instance is used
        sessionPromiseRef.current?.then((session) => {
          session.sendRealtimeInput({
            media: { data: pcmBase64, mimeType: 'audio/pcm;rate=16000' }
          });
        });
      };

      source.connect(processor);
      processor.connect(inputCtx.destination);
    };

    init();

    return () => {
      sessionPromiseRef.current?.then(s => s.close());
      audioContextRef.current?.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[300] bg-slate-900/90 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-white">
      <button onClick={onClose} className="absolute top-8 right-8 p-3 hover:bg-white/10 rounded-full transition-colors">
        <X className="w-8 h-8" />
      </button>

      <div className="w-48 h-48 rounded-full bg-blue-600/20 flex items-center justify-center relative mb-12">
        <div className={`absolute inset-0 rounded-full border-4 border-blue-500/30 ${active ? 'animate-ping' : ''}`} />
        <div className={`w-32 h-32 rounded-full bg-blue-500 flex items-center justify-center shadow-2xl shadow-blue-500/50 transition-transform duration-500 ${isSpeaking ? 'scale-110' : 'scale-100'}`}>
          {isSpeaking ? <Volume2 className="w-12 h-12" /> : <Mic className="w-12 h-12" />}
        </div>
      </div>

      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-2 text-blue-400 font-black uppercase tracking-widest text-sm">
          <Sparkles className="w-4 h-4" /> Live AI Mentor
        </div>
        <h2 className="text-3xl font-black">
          {isSpeaking ? (lang === 'ka' ? 'ინსტრუქტორი საუბრობს...' : 'Mentor is speaking...') : (lang === 'ka' ? 'გისმენთ...' : 'Listening...')}
        </h2>
        <p className="text-slate-400 max-w-xs mx-auto text-sm leading-relaxed">
          {lang === 'ka' ? 'შეგიძლიათ დასვათ ნებისმიერი კითხვა მართვის მოწმობასთან დაკავშირებით.' : 'Ask anything about driving rules or Munich specifics.'}
        </p>
      </div>

      <div className="mt-12 p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center gap-4">
        <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
        <span className="text-xs font-bold text-slate-300 uppercase tracking-tighter">{status}</span>
      </div>
    </div>
  );
};
