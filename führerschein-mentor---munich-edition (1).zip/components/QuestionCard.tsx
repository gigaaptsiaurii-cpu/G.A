
import React, { useState } from 'react';
import { Question, Language } from '../types';
import { CheckCircle2, XCircle, Info, Sparkles, Volume2, BrainCircuit } from 'lucide-react';
import { gemini, playPCM } from '../services/geminiService';

interface Props {
  question: Question;
  lang: Language;
  onAnswer: (correct: boolean) => void;
}

export const QuestionCard: React.FC<Props> = ({ question, lang, onAnswer }) => {
  const [selected, setSelected] = useState<number[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [aiExplanation, setAiExplanation] = useState<{ explanation: string, mnemonic?: string } | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [playingAudio, setPlayingAudio] = useState(false);

  const toggleOption = (idx: number) => {
    if (submitted) return;
    setSelected(prev => 
      prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx]
    );
  };

  const handleSpeech = async () => {
    setPlayingAudio(true);
    const audioData = await gemini.speakText(question.questionDe);
    if (audioData) await playPCM(audioData);
    setPlayingAudio(false);
  };

  const handleSubmit = () => {
    if (submitted || selected.length === 0) return;
    const isCorrect = 
      selected.length === question.correctIndices.length &&
      selected.every(idx => question.correctIndices.includes(idx));
    setSubmitted(true);
    onAnswer(isCorrect);
  };

  const askAi = async () => {
    setLoadingAi(true);
    const result = await gemini.explainConcept(question.questionDe, lang);
    setAiExplanation(result);
    setLoadingAi(false);
  };

  const isCorrect = (idx: number) => question.correctIndices.includes(idx);
  const isSelected = (idx: number) => selected.includes(idx);

  return (
    <div className="bg-white rounded-3xl shadow-xl border border-slate-100 transition-all overflow-hidden">
      <div className="p-6">
        <div className="flex justify-between items-start mb-6">
          <div className="flex gap-2">
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider">
              {question.points} Points
            </span>
            <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider">
              {question.category}
            </span>
          </div>
          <button 
            onClick={handleSpeech}
            disabled={playingAudio}
            className="p-3 bg-slate-50 hover:bg-slate-100 rounded-2xl transition-all text-slate-400 hover:text-blue-600 border border-slate-100"
          >
            <Volume2 className={`w-5 h-5 ${playingAudio ? 'animate-pulse text-blue-600' : ''}`} />
          </button>
        </div>

        <div className="mb-8 space-y-2">
          <h2 className="text-xl font-black text-slate-800 leading-tight">
            {question.questionDe}
          </h2>
          <p className="text-base font-bold text-slate-500 leading-snug italic">
            {question.questionKa}
          </p>
        </div>

        <div className="space-y-3 mb-8">
          {question.optionsDe.map((optionDe, idx) => {
            const optionKa = question.optionsKa[idx];
            let styles = "p-5 rounded-2xl border-2 transition-all flex items-start gap-4 cursor-pointer ";
            if (!submitted) {
              styles += isSelected(idx) ? "border-blue-500 bg-blue-50/50 shadow-lg shadow-blue-50" : "border-slate-100 hover:border-slate-200 bg-white";
            } else {
              if (isCorrect(idx)) styles += "border-green-500 bg-green-50 shadow-lg shadow-green-50";
              else if (isSelected(idx)) styles += "border-red-500 bg-red-50";
              else styles += "border-slate-100 opacity-60";
            }
            return (
              <div key={idx} onClick={() => toggleOption(idx)} className={styles}>
                <div className={`mt-1 flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center ${isSelected(idx) ? 'bg-blue-500 border-blue-500' : 'border-slate-300'}`}>
                  {isSelected(idx) && <div className="w-2 h-2 bg-white rounded-full" />}
                </div>
                <div className="flex flex-col gap-1 flex-1">
                  <span className="text-slate-900 font-bold text-sm leading-tight">{optionDe}</span>
                  <span className="text-slate-500 font-medium text-xs leading-tight">{optionKa}</span>
                </div>
                {submitted && isCorrect(idx) && <CheckCircle2 className="ml-auto text-green-600 w-6 h-6 flex-shrink-0" />}
                {submitted && !isCorrect(idx) && isSelected(idx) && <XCircle className="ml-auto text-red-600 w-6 h-6 flex-shrink-0" />}
              </div>
            );
          })}
        </div>

        <div className="flex gap-4">
          {!submitted ? (
            <button 
              onClick={handleSubmit} 
              disabled={selected.length === 0} 
              className="flex-1 bg-slate-900 text-white py-5 rounded-2xl font-black hover:bg-slate-800 disabled:opacity-50 transition-all shadow-xl shadow-slate-200 active:scale-95"
            >
              {lang === 'de' ? 'Antwort prüfen' : 'პასუხის შემოწმება'}
            </button>
          ) : (
            <div className="flex-1 space-y-4">
              <div className="p-5 bg-blue-50/80 border-l-4 border-blue-500 text-blue-900 text-sm rounded-r-2xl leading-relaxed">
                <div className="flex items-center gap-2 mb-2 font-black uppercase text-[10px] tracking-widest text-blue-700">
                  <Info className="w-4 h-4" />
                  {lang === 'de' ? 'Erklärung' : 'განმარტება'}
                </div>
                {lang === 'de' ? question.explanationDe : question.explanationKa}
              </div>

              {aiExplanation && (
                <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 space-y-4">
                   <div className="p-5 bg-purple-50/80 border-l-4 border-purple-500 rounded-r-2xl text-slate-700 text-sm italic border border-purple-100">
                    <div className="flex items-center gap-2 mb-2 font-black uppercase text-[10px] tracking-widest text-purple-700">
                      <Sparkles className="w-4 h-4" /> AI Deep Dive
                    </div>
                    {aiExplanation.explanation}
                  </div>
                  
                  {aiExplanation.mnemonic && (
                    <div className="p-5 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-4">
                      <BrainCircuit className="w-6 h-6 text-amber-600 flex-shrink-0" />
                      <div>
                        <h4 className="text-[10px] font-black text-amber-700 uppercase tracking-widest mb-1">Mnemonic Aid</h4>
                        <p className="text-sm font-bold text-amber-900 leading-relaxed">{aiExplanation.mnemonic}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {!aiExplanation && (
                <button 
                  onClick={askAi} 
                  disabled={loadingAi} 
                  className="w-full flex items-center justify-center gap-3 py-4 border-2 border-purple-200 text-purple-700 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-purple-50 transition-all active:scale-95"
                >
                  <Sparkles className={`w-4 h-4 ${loadingAi ? 'animate-spin' : ''}`} />
                  {loadingAi ? 'AI Tutor Thinking...' : 'Explain with AI Mnemonics'}
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
