
import React, { useState, useEffect } from 'react';
import { Question, Language, ExamState } from '../types';
import { ChevronLeft, ChevronRight, Clock, Flag, CheckCircle2, XCircle, RotateCcw, Home, X } from 'lucide-react';

interface Props {
  questions: Question[];
  lang: Language;
  onClose: (passed?: boolean, points?: number) => void;
}

export const ExamSimulation: React.FC<Props> = ({ questions, lang, onClose }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [exam, setExam] = useState<ExamState>({
    answers: {},
    startTime: Date.now(),
    isFinished: false
  });
  const [timeLeft, setTimeLeft] = useState(45 * 60); // 45 minutes

  useEffect(() => {
    if (exam.isFinished) return;
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          finishExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [exam.isFinished]);

  const toggleOption = (idx: number) => {
    if (exam.isFinished) return;
    const qId = questions[currentIndex].id;
    const currentAnswers = exam.answers[qId] || [];
    const newAnswers = currentAnswers.includes(idx)
      ? currentAnswers.filter(i => i !== idx)
      : [...currentAnswers, idx];
    
    setExam(prev => ({
      ...prev,
      answers: { ...prev.answers, [qId]: newAnswers }
    }));
  };

  const finishExam = () => {
    setExam(prev => ({ ...prev, isFinished: true }));
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const calculateScore = () => {
    let totalPoints = 0;
    let earnedPoints = 0;
    let mistakes = 0;

    questions.forEach(q => {
      totalPoints += q.points;
      const userAns = exam.answers[q.id] || [];
      const isCorrect = userAns.length === q.correctIndices.length &&
                        userAns.every(i => q.correctIndices.includes(i));
      if (isCorrect) {
        earnedPoints += q.points;
      } else {
        mistakes += q.points;
      }
    });

    return { earnedPoints, totalPoints, mistakes, passed: mistakes <= 10 };
  };

  const currentQuestion = questions[currentIndex];
  const userAnswers = exam.answers[currentQuestion.id] || [];

  if (exam.isFinished) {
    const { earnedPoints, totalPoints, mistakes, passed } = calculateScore();
    return (
      <div className="min-h-screen bg-slate-50 p-6 animate-in fade-in duration-500">
        <div className="max-w-2xl mx-auto space-y-6">
          <div className={`p-10 rounded-3xl text-center shadow-xl ${passed ? 'bg-green-600' : 'bg-red-600'} text-white`}>
            <div className="mb-4 inline-flex p-4 bg-white/20 rounded-full">
              {passed ? <CheckCircle2 className="w-12 h-12" /> : <XCircle className="w-12 h-12" />}
            </div>
            <h2 className="text-3xl font-black mb-2">
              {passed 
                ? (lang === 'ka' ? 'გილოცავთ! გამოცდა ჩაბარებულია' : 'Bestanden! Glückwunsch')
                : (lang === 'ka' ? 'სამწუხაროდ, გამოცდა ვერ ჩაბარდა' : 'Nicht bestanden')}
            </h2>
            <p className="text-white/80 font-bold">
              {lang === 'ka' ? `დაგროვილი ქულები: ${earnedPoints} / ${totalPoints}` : `Erreichte Punkte: ${earnedPoints} / ${totalPoints}`}
            </p>
            <p className="text-sm mt-2 opacity-60">
              {lang === 'ka' ? `შეცდომის ქულა: ${mistakes} (ლიმიტი: 10)` : `Fehlerpunkte: ${mistakes} (Limit: 10)`}
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <h3 className="font-black uppercase text-xs tracking-widest text-slate-400 mt-4">Review Answers</h3>
            {questions.map((q, i) => {
              const uAns = exam.answers[q.id] || [];
              const isCorrect = uAns.length === q.correctIndices.length && uAns.every(idx => q.correctIndices.includes(idx));
              return (
                <div key={q.id} className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
                  <div className="flex flex-col flex-1 gap-1">
                    <span className="text-xs font-bold text-slate-400">#{i + 1}</span>
                    <span className="text-sm font-bold text-slate-700 truncate max-w-[400px]">{q.questionDe}</span>
                    <span className="text-[10px] text-slate-400 truncate max-w-[400px]">{q.questionKa}</span>
                  </div>
                  {isCorrect ? <CheckCircle2 className="text-green-500 w-5 h-5 flex-shrink-0 ml-4" /> : <XCircle className="text-red-500 w-5 h-5 flex-shrink-0 ml-4" />}
                </div>
              );
            })}
          </div>

          <button 
            onClick={() => onClose(passed, earnedPoints)}
            className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-slate-800 transition-all"
          >
            <Home className="w-5 h-5" />
            {lang === 'ka' ? 'მთავარ მენიუში დაბრუნება' : 'Zurück zum Hauptmenü'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-slate-900 text-white px-6 py-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => onClose()}
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
            title={lang === 'ka' ? 'გამოსვლა' : 'Beenden'}
          >
            <X className="w-6 h-6" />
          </button>
          <div className="bg-white/10 px-3 py-1 rounded-lg flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <span className="font-mono font-bold text-lg">{formatTime(timeLeft)}</span>
          </div>
          <span className="text-sm font-bold opacity-60">{currentIndex + 1} / {questions.length}</span>
        </div>
        <button 
          onClick={finishExam}
          className="bg-red-600 hover:bg-red-700 px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-colors flex items-center gap-2"
        >
          <Flag className="w-4 h-4" /> {lang === 'ka' ? 'დასრულება' : 'Abgeben'}
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6 max-w-2xl mx-auto w-full">
        <div className="mb-8 space-y-3">
          <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider mb-2 inline-block">
            {currentQuestion.points} Points • {currentQuestion.category}
          </span>
          <h2 className="text-2xl font-black text-slate-900 leading-tight">
            {currentQuestion.questionDe}
          </h2>
          <p className="text-lg font-bold text-slate-500 leading-snug border-l-4 border-slate-200 pl-4">
            {currentQuestion.questionKa}
          </p>
        </div>

        <div className="space-y-3">
          {currentQuestion.optionsDe.map((optionDe, idx) => {
            const optionKa = currentQuestion.optionsKa[idx];
            const isSelected = userAnswers.includes(idx);
            return (
              <div 
                key={idx} 
                onClick={() => toggleOption(idx)}
                className={`p-5 rounded-2xl border-2 transition-all flex items-start gap-4 cursor-pointer ${
                  isSelected ? 'border-blue-500 bg-blue-50/50' : 'border-slate-100 hover:border-slate-200'
                }`}
              >
                <div className={`mt-1 flex-shrink-0 w-6 h-6 rounded-lg border-2 flex items-center justify-center ${
                  isSelected ? 'bg-blue-500 border-blue-500' : 'border-slate-300'
                }`}>
                  {isSelected && <div className="w-2 h-2 bg-white rounded-full" />}
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-slate-900 font-bold text-sm leading-tight">{optionDe}</span>
                  <span className="text-slate-500 font-medium text-xs leading-tight">{optionKa}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Navigation Footer */}
      <div className="p-6 bg-slate-50 border-t flex justify-between gap-4">
        <button 
          onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
          disabled={currentIndex === 0}
          className="flex-1 flex items-center justify-center gap-2 py-4 bg-white border border-slate-200 rounded-2xl font-bold text-slate-600 disabled:opacity-30 transition-all hover:bg-slate-100"
        >
          <ChevronLeft className="w-5 h-5" /> {lang === 'ka' ? 'უკან' : 'Zurück'}
        </button>
        <button 
          onClick={() => setCurrentIndex(prev => Math.min(questions.length - 1, prev + 1))}
          disabled={currentIndex === questions.length - 1}
          className="flex-1 flex items-center justify-center gap-2 py-4 bg-slate-900 text-white rounded-2xl font-bold disabled:opacity-30 transition-all hover:bg-slate-800"
        >
          {lang === 'ka' ? 'შემდეგი' : 'Weiter'} <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Question Grid */}
      <div className="px-6 py-4 bg-white border-t overflow-x-auto">
        <div className="flex gap-2 min-w-max">
          {questions.map((q, i) => (
            <button
              key={q.id}
              onClick={() => setCurrentIndex(i)}
              className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-black transition-all ${
                currentIndex === i ? 'bg-blue-600 text-white scale-110 shadow-lg' : 
                (exam.answers[q.id]?.length ? 'bg-slate-200 text-slate-700' : 'bg-slate-100 text-slate-400')
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
