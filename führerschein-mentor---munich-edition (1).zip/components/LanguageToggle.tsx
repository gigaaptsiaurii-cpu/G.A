
import React from 'react';
import { Language } from '../types';

interface Props {
  current: Language;
  onChange: (lang: Language) => void;
}

export const LanguageToggle: React.FC<Props> = ({ current, onChange }) => {
  return (
    <div className="flex bg-slate-200 rounded-lg p-1">
      <button
        onClick={() => onChange('de')}
        className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
          current === 'de' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        Deutsch
      </button>
      <button
        onClick={() => onChange('ka')}
        className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
          current === 'ka' ? 'bg-white shadow-sm text-red-600' : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        ქართული
      </button>
    </div>
  );
};
