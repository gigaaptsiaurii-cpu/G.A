
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Language, UserProgress, Question, ViewMode } from './types';
import { SAMPLE_QUESTIONS } from './data/questions';
import { LanguageToggle } from './components/LanguageToggle';
import { QuestionCard } from './components/QuestionCard';
import { LiveTutor } from './components/LiveTutor';
import { ExamSimulation } from './components/ExamSimulation';
import { Trophy, BookOpen, MapPin, Search, X, ExternalLink, Camera, Sparkles, Mic, ShieldCheck, Key, GraduationCap, ClipboardList, Timer, ChevronLeft, Layers, AlertTriangle, Car, Milestone, Leaf, Settings, UserCheck, Info, Play } from 'lucide-react';
import { gemini } from './services/geminiService';

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('ka');
  const [view, setView] = useState<ViewMode>('home');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [progress, setProgress] = useState<UserProgress>({
    answeredIds: [],
    correctIds: [],
    categoryProgress: {}
  });
  const [searchOpen, setSearchOpen] = useState(false);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [tutorOpen, setTutorOpen] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{text: string, links: any[]} | null>(null);
  const [searching, setSearching] = useState(false);
  const [hasPaidKey, setHasPaidKey] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    checkApiKey();
  }, []);

  const checkApiKey = async () => {
    if ((window as any).aistudio) {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasPaidKey(selected);
    }
  };

  const handleOpenKeySelection = async () => {
    if ((window as any).aistudio) {
      await (window as any).aistudio.openSelectKey();
      setHasPaidKey(true);
    }
  };

  // Filtered questions based on selected category
  const activeQuestions = useMemo(() => {
    if (!selectedCategory) return SAMPLE_QUESTIONS;
    return SAMPLE_QUESTIONS.filter(q => q.category === selectedCategory);
  }, [selectedCategory]);

  const currentQuestion = activeQuestions[currentQuestionIndex];

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setCurrentQuestionIndex(0);
    setView('practice');
  };

  const startCamera = async () => {
    setScannerOpen(true);
    setScanResult(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment', width: { ideal: 1280 } } 
      });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err: any) {
      console.error("Camera error");
    }
  };

  const captureAndAnalyze = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    setScanning(true);
    const context = canvasRef.current.getContext('2d');
    const width = 800;
    const height = (videoRef.current.videoHeight / videoRef.current.videoWidth) * width;
    canvasRef.current.width = width;
    canvasRef.current.height = height;
    context?.drawImage(videoRef.current, 0, 0, width, height);
    const base64 = canvasRef.current.toDataURL('image/jpeg', 0.8).split(',')[1];
    const result = await gemini.analyzeSign(base64, lang);
    setScanResult(result);
    setScanning(false);
    (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
  };

  const closeScanner = () => {
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
    }
    setScannerOpen(false);
    setScanResult(null);
  };

  const handleAnswer = (correct: boolean) => {
    setProgress(prev => ({
      ...prev,
      answeredIds: [...prev.answeredIds, currentQuestion.id],
      correctIds: correct ? [...prev.correctIds, currentQuestion.id] : prev.correctIds
    }));
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setSearching(true);
    const res = await gemini.searchRules(searchQuery);
    setSearchResults(res);
    setSearching(false);
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < activeQuestions.length - 1) setCurrentQuestionIndex(prev => prev + 1);
    else {
      setView('home');
      setSelectedCategory(null);
    }
  };

  // Official German Driving Theory Categories breakdown
  const officialCategories = [
    { id: 'hazard', nameKa: 'საფრთხეების ამოცნობა', nameDe: 'Gefahrenlehre', count: 285, icon: <AlertTriangle className="w-4 h-4" /> },
    { id: 'behavior', nameKa: 'ქცევის წესები მოძრაობაში', nameDe: 'Verhalten im Straßenverkehr', count: 320, icon: <Car className="w-4 h-4" /> },
    { id: 'priority', nameKa: 'გზის დათმობა და პრიორიტეტები', nameDe: 'Vorfahrt & Vorrang', count: 165, icon: <Milestone className="w-4 h-4" /> },
    { id: 'signs', nameKa: 'საგზაო ნიშნები და მონიშვნები', nameDe: 'Verkehrszeichen', count: 195, icon: <Layers className="w-4 h-4" /> },
    { id: 'environment', nameKa: 'გარემოს დაცვა და ეკო-მართვა', nameDe: 'Umweltschutz', count: 65, icon: <Leaf className="w-4 h-4" /> },
    { id: 'technical', nameKa: 'ავტომობილის აგებულება / ტექნიკა', nameDe: 'Technik', count: 145, icon: <Settings className="w-4 h-4" /> },
    { id: 'personal', nameKa: 'მძღოლის ფსიქოფიზიკური მზაობა', nameDe: 'Eignung & Befähigung', count: 105, icon: <UserCheck className="w-4 h-4" /> },
  ];

  if (view === 'exam') {
    return <ExamSimulation 
      questions={SAMPLE_QUESTIONS} 
      lang={lang} 
      onClose={() => setView('home')} 
    />;
  }

  return (
    <div className="min-h-screen pb-32 bg-slate-50">
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => {setView('home'); setSelectedCategory(null);}}>
            <div className="w-10 h-10 bg-slate-900 rounded-lg flex items-center justify-center text-white font-bold">FM</div>
            <div>
              <h1 className="text-lg font-bold text-slate-900">Mentor Munich</h1>
              <div className="flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-400" />
                <span className="text-[10px] text-slate-500 font-black uppercase tracking-tighter">Munich, DE</span>
                {hasPaidKey && <span className="flex items-center gap-0.5 ml-2 px-1.5 py-0.5 bg-green-100 text-green-700 text-[8px] font-black rounded uppercase"><ShieldCheck className="w-2.5 h-2.5" /> Pro</span>}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {!hasPaidKey && (
              <button onClick={handleOpenKeySelection} className="p-2 text-blue-600 hover:bg-blue-50 rounded-full transition-colors flex items-center gap-2">
                <Key className="w-5 h-5" />
                <span className="text-xs font-bold hidden sm:inline">Upgrade</span>
              </button>
            )}
            <LanguageToggle current={lang} onChange={setLang} />
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 mt-8">
        {view === 'home' ? (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl shadow-slate-200">
              <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
              <div className="relative z-10">
                <h2 className="text-3xl font-black mb-4 leading-tight">
                  {lang === 'ka' ? 'მოემზადე მართვის მოწმობისთვის' : 'Bereit für den Führerschein?'}
                </h2>
                <div className="flex gap-4">
                   <button onClick={() => setView('exam')} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-4 px-6 rounded-2xl font-black flex items-center justify-center gap-3 shadow-lg shadow-blue-500/20 transition-all active:scale-95">
                    <Timer className="w-5 h-5" />
                    {lang === 'ka' ? 'გამოცდის დაწყება' : 'Prüfung starten'}
                  </button>
                  <button onClick={() => {setView('practice'); setSelectedCategory(null);}} className="flex-1 bg-white/10 hover:bg-white/20 text-white py-4 px-6 rounded-2xl font-black flex items-center justify-center gap-3 backdrop-blur-md border border-white/10 transition-all active:scale-95">
                    <BookOpen className="w-5 h-5" />
                    {lang === 'ka' ? 'ყველა ტესტი' : 'Alle Üben'}
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => setTutorOpen(true)} className="p-6 bg-white border border-slate-200 rounded-3xl text-left hover:border-blue-500 transition-all group shadow-sm">
                <Mic className="w-8 h-8 text-blue-600 mb-4 group-hover:scale-110 transition-transform" />
                <h4 className="font-black text-lg text-slate-900">Live Mentor</h4>
                <p className="text-xs text-slate-500">{lang === 'ka' ? 'AI ხმოვანი ასისტენტი' : 'Sprich mit dem Mentor'}</p>
              </button>
              <button onClick={startCamera} className="p-6 bg-white border border-slate-200 rounded-3xl text-left hover:border-blue-500 transition-all group shadow-sm">
                <Camera className="w-8 h-8 text-purple-600 mb-4 group-hover:scale-110 transition-transform" />
                <h4 className="font-black text-lg text-slate-900">Sign Scan</h4>
                <p className="text-xs text-slate-500">{lang === 'ka' ? 'ნიშნის ამოცნობა' : 'Schild erkennen'}</p>
              </button>
            </div>

            {/* Comprehensive Course Overview */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-sm font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                  <Layers className="w-4 h-4" /> {lang === 'ka' ? 'სწავლა კატეგორიების მიხედვით' : 'Lernen nach Kategorien'}
                </h3>
              </div>
              
              <div className="space-y-3">
                {officialCategories.map((cat) => (
                  <button 
                    key={cat.id} 
                    onClick={() => handleCategoryClick(cat.id)}
                    className="w-full group p-4 bg-white border border-slate-100 rounded-2xl hover:border-blue-500 hover:bg-blue-50/50 transition-all flex items-center justify-between text-left active:scale-95"
                  >
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-slate-50 rounded-xl group-hover:bg-white transition-colors text-slate-400 group-hover:text-blue-600 shadow-sm">
                        {cat.icon}
                      </div>
                      <div>
                        <div className="text-sm font-black text-slate-800">{lang === 'ka' ? cat.nameKa : cat.nameDe}</div>
                        <div className="text-[10px] font-bold text-slate-400 italic">{cat.nameDe}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-sm font-black text-slate-700">{cat.count}</div>
                        <div className="text-[9px] font-black text-slate-400 uppercase">{lang === 'ka' ? 'კითხვა' : 'Fragen'}</div>
                      </div>
                      <div className="p-2 bg-blue-600 rounded-lg text-white opacity-0 group-hover:opacity-100 transition-opacity">
                        <Play className="w-3 h-3 fill-current" />
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              <div className="mt-6 p-4 bg-blue-50/50 rounded-2xl border border-blue-100 flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-blue-800 leading-relaxed">
                  {lang === 'ka' 
                    ? "აირჩიეთ ნებისმიერი კატეგორია ტესტების დასაწყებად. თითოეული თემა შეიცავს კითხვებს რეალური საგამოცდო ბაზიდან." 
                    : "Wählen Sie eine Kategorie, um die Übung zu starten. Jedes Thema enthält offizielle Prüfungsfragen."}
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex items-center justify-between">
              <button onClick={() => {setView('home'); setSelectedCategory(null);}} className="flex items-center gap-2 text-slate-500 font-bold hover:text-slate-900 transition-colors">
                <ChevronLeft className="w-5 h-5" /> {lang === 'ka' ? 'მთავარი' : 'Home'}
              </button>
              <div className="flex flex-col items-end">
                <div className="text-xs font-black text-slate-400 uppercase tracking-widest">
                  {currentQuestionIndex + 1} / {activeQuestions.length}
                </div>
                {selectedCategory && (
                  <span className="text-[10px] font-black text-blue-600 uppercase">
                    {officialCategories.find(c => c.id === selectedCategory)?.nameKa}
                  </span>
                )}
              </div>
            </div>
            
            {currentQuestion ? (
              <>
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 transition-all duration-500" style={{ width: `${((currentQuestionIndex + 1) / activeQuestions.length) * 100}%` }} />
                  </div>
                </div>

                <QuestionCard 
                  question={currentQuestion} 
                  lang={lang} 
                  onAnswer={handleAnswer}
                />

                {progress.answeredIds.includes(currentQuestion.id) && (
                  <button onClick={nextQuestion} className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black hover:bg-slate-800 shadow-xl shadow-slate-200 transition-all flex items-center justify-center gap-2">
                    {lang === 'de' ? 'Nächste Frage' : 'შემდეგი კითხვა'}
                  </button>
                )}
              </>
            ) : (
              <div className="bg-white rounded-[2.5rem] p-12 text-center border-2 border-dashed border-slate-200">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="w-10 h-10 text-blue-400" />
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-2">კითხვები მალე დაემატება</h3>
                <p className="text-slate-500 text-sm mb-8">ამ კატეგორიისთვის საჩვენებელ ბაზაში კითხვები ჯერ არ გვაქვს, მაგრამ AI-ს შეუძლია დაგეხმაროთ წესების გარკვევაში.</p>
                <button onClick={() => setView('home')} className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black">უკან დაბრუნება</button>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Persistent Bottom Search Bar */}
      <div className="fixed bottom-8 left-0 right-0 flex justify-center px-4 pointer-events-none">
        <div className="pointer-events-auto w-full max-w-md bg-white/80 backdrop-blur-xl border border-slate-200 h-16 rounded-2xl shadow-2xl flex items-center px-4 gap-3 group focus-within:ring-2 ring-blue-500/20 transition-all">
          <Search className="w-5 h-5 text-slate-400" />
          <input className="flex-1 bg-transparent border-none outline-none font-medium text-sm text-slate-900" placeholder={lang === 'ka' ? 'ჰკითხე AI-ს წესებზე...' : 'Frag den Mentor...'} onFocus={() => setSearchOpen(true)} />
          <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-blue-600" />
          </div>
        </div>
      </div>

      {tutorOpen && <LiveTutor lang={lang} onClose={() => setTutorOpen(false)} />}
      
      {/* Search and Scanner Overlays omitted for brevity as they remain unchanged */}
      {searchOpen && (
        <div className="fixed inset-0 z-[150] bg-slate-900/60 backdrop-blur-md flex items-end sm:items-center justify-center p-4">
          <div className="w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <form onSubmit={handleSearch} className="p-6 border-b flex items-center gap-4 bg-slate-50">
              <Search className="w-6 h-6 text-slate-400" />
              <input autoFocus placeholder="Ex: 'Can I park in front of my own driveway?'" className="flex-1 bg-transparent border-none outline-none text-slate-900 font-bold text-lg" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
              <button type="button" onClick={() => {setSearchOpen(false); setSearchResults(null);}} className="p-2 hover:bg-slate-200 rounded-full"><X className="w-6 h-6" /></button>
            </form>
            <div className="flex-1 overflow-y-auto p-8">
              {searching ? (
                <div className="flex flex-col items-center justify-center py-20 text-slate-400 gap-4">
                  <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                  <span className="font-black uppercase text-xs tracking-widest">Searching Legal Data...</span>
                </div>
              ) : searchResults ? (
                <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <p className="text-slate-800 leading-relaxed text-lg font-medium">{searchResults.text}</p>
                </div>
              ) : <div className="text-center py-20 text-slate-400 italic">Try: "What is the fine for speeding in Munich?"</div>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
