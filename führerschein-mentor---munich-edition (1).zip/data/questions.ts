
import { Question } from '../types';

export const SAMPLE_QUESTIONS: Question[] = [
  {
    id: '1',
    category: 'priority',
    points: 5,
    questionDe: "Was gilt bei dieser Rechts-vor-Links Kreuzung ohne Beschilderung?",
    questionKa: "რა წესი მოქმედებს ამ გზაჯვარედინზე, სადაც არ არის საგზაო ნიშნები?",
    optionsDe: [
      "Ich muss warten, wenn ein Fahrzeug von rechts kommt.",
      "Ich darf immer zuerst fahren.",
      "Fahrzeuge von links haben Vorrang."
    ],
    optionsKa: [
      "უნდა დაველოდო, თუ ავტომობილი მოდის მარჯვნიდან.",
      "ყოველთვის მე მაქვს გავლის უფლება.",
      "მარცხნიდან მომავალ ავტომობილებს აქვთ უპირატესობა."
    ],
    correctIndices: [0],
    explanationDe: "In Deutschland gilt an Kreuzungen ohne Schilder die Grundregel 'Rechts vor Links'.",
    explanationKa: "გერმანიაში გზაჯვარედინებზე ნიშნების გარეშე მოქმედებს ძირითადი წესი: 'მარჯვნიდან მომავალს აქვს უპირატესობა'."
  },
  {
    id: '2',
    category: 'signs',
    points: 3,
    questionDe: "Was bedeutet das kreisförmige blaue Schild mit dem weißen Fahrrad?",
    questionKa: "რას ნიშნავს წრიული ლურჯი ნიშანი თეთრი ველოსიპედით?",
    optionsDe: [
      "Sonderweg für Radfahrer (Benutzungspflicht)",
      "Verbot für Radfahrer",
      "Empfehlung für Radfahrer"
    ],
    optionsKa: [
      "სავალდებულო გზა ველოსიპედისტებისთვის",
      "ველოსიპედით მოძრაობა აკრძალულია",
      "რეკომენდაცია ველოსიპედისტებისთვის"
    ],
    correctIndices: [0],
    explanationDe: "Blaue Schilder mit Symbolen sind Gebotszeichen. Radfahrer müssen diesen Weg benutzen.",
    explanationKa: "ლურჯი ნიშნები სიმბოლოებით არის სავალდებულო ნიშნები. ველოსიპედისტები ვალდებულნი არიან ისარგებლონ ამ გზით."
  },
  {
    id: '3',
    category: 'environment',
    points: 2,
    questionDe: "Sie fahren in die Münchner Umweltzone. Was benötigen Sie?",
    questionKa: "თქვენ შედიხართ მიუნხენის გარემოსდაცვით ზონაში (Umweltzone). რა გჭირდებათ?",
    optionsDe: [
      "Eine grüne Umweltplakette",
      "Eine Parkscheibe",
      "Einen Anwohnerparkausweis"
    ],
    optionsKa: [
      "მწვანე ეკოლოგიური სტიკერი (Umweltplakette)",
      "პარკირების დისკი",
      "ადგილობრივი მაცხოვრებლის პარკირების ნებართვა"
    ],
    correctIndices: [0],
    explanationDe: "In weiten Teilen Münchens (innerhalb des Mittleren Rings) ist eine grüne Plakette Pflicht.",
    explanationKa: "მიუნხენის დიდ ნაწილში (Mittlerer Ring-ის შიგნით) მწვანე სტიკერი (Plakette) სავალდებულოა."
  },
  {
    id: '4',
    category: 'hazard',
    points: 4,
    questionDe: "Wie groß muss der Seitenabstand beim Überholen von Radfahrern innerorts sein?",
    questionKa: "რა მანძილი უნდა დაიცვათ ქალაქში ველოსიპედისტის გასწრებისას?",
    optionsDe: [
      "Mindestens 1,5 Meter",
      "Mindestens 1,0 Meter",
      "Mindestens 2,0 Meter"
    ],
    optionsKa: [
      "მინიმუმ 1,5 მეტრი",
      "მინიმუმ 1,0 მეტრი",
      "მინიმუმ 2,0 მეტრი"
    ],
    correctIndices: [0],
    explanationDe: "Innerorts sind 1,5 Meter, außerorts 2 Meter Seitenabstand zu Radfahrern gesetzlich vorgeschrieben.",
    explanationKa: "ქალაქში 1,5 მეტრი, ხოლო ქალაქგარეთ 2 მეტრი გვერდითი მანძილია საჭირო ველოსიპედისტებთან."
  },
  {
    id: '5',
    category: 'technical',
    points: 3,
    questionDe: "Was ist die gesetzliche Mindestprofiltiefe für Sommerreifen in Deutschland?",
    questionKa: "რა არის საზაფხულო საბურავების პროტექტორის მინიმალური სიღრმე გერმანიაში?",
    optionsDe: [
      "1,6 mm",
      "1,0 mm",
      "3,0 mm"
    ],
    optionsKa: [
      "1,6 მმ",
      "1,0 მმ",
      "3,0 მმ"
    ],
    correctIndices: [0],
    explanationDe: "Gesetzlich sind 1,6 mm vorgeschrieben, Experten empfehlen jedoch mindestens 3 mm für Sommerreifen.",
    explanationKa: "კანონით 1,6 მმ-ია დადგენილი, თუმცა ექსპერტები 3 მმ-ს გვირჩევენ."
  },
  {
    id: '6',
    category: 'priority',
    points: 4,
    questionDe: "Eine Straßenbahn möchte an einer Haltestelle in München losfahren. Wer hat Vorrang?",
    questionKa: "მიუნხენში ტრამვაის გაჩერებიდან დაძვრა უნდა. ვის აქვს უპირატესობა?",
    optionsDe: [
      "Die Straßenbahn, wenn sie blinkt.",
      "Der Pkw-Verkehr hat immer Vorrang.",
      "Die Straßenbahn muss immer warten."
    ],
    optionsKa: [
      "ტრამვაის, თუ ის მოხვევის სიგნალს იყენებს.",
      "ავტომობილებს ყოველთვის აქვთ უპირატესობა.",
      "ტრამვაი ყოველთვის უნდა დაელოდოს."
    ],
    correctIndices: [0],
    explanationDe: "Straßenbahnen haben beim Anfahren von Haltestellen oft besondere Vorrechte, achten Sie auf die Signale.",
    explanationKa: "მიუნხენში ტრამვაებს გაჩერებიდან დაძვრისას ხშირად აქვთ უპირატესობა, აკონტროლეთ მათი სიგნალები."
  },
  {
    id: '7',
    category: 'hazard',
    points: 4,
    questionDe: "Wie berechnet man den Reaktionsweg nach der Faustformel? (Geschwindigkeit v)",
    questionKa: "როგორ გამოითვლება რეაქციის მანძილი ფორმულით? (სიჩქარე v)",
    optionsDe: [
      "(v / 10) * 3",
      "(v / 10) * (v / 10)",
      "(v / 10) * 5"
    ],
    optionsKa: [
      "(სიჩქარე / 10) * 3",
      "(სიჩქარე / 10) * (სიჩქარე / 10)",
      "(სიჩქარე / 10) * 5"
    ],
    correctIndices: [0],
    explanationDe: "Der Reaktionsweg ist die Strecke, die das Fahrzeug während der Schrecksekunde zurücklegt.",
    explanationKa: "რეაქციის მანძილი არის მანძილი, რომელსაც გადიხართ რეაგირებამდე (დაახლ. 1 წამი)."
  },
  {
    id: '8',
    category: 'signs',
    points: 3,
    questionDe: "Was bedeutet das rote achteckige Schild 'STOP'?",
    questionKa: "რას ნიშნავს წითელი რვაკუთხა ნიშანი 'STOP'?",
    optionsDe: [
      "Anhalten und Vorrang gewähren.",
      "Nur Vorrang gewähren, kein Halt nötig.",
      "Nur Anhalten, wenn Querverkehr kommt."
    ],
    optionsKa: [
      "გაჩერება და გზის დათმობა.",
      "მხოლოდ გზის დათმობა, გაჩერება საჭირო არაა.",
      "გაჩერება მხოლოდ მაშინ, თუ სხვა მანქანა მოდის."
    ],
    correctIndices: [0],
    explanationDe: "Man muss an der Haltelinie (oder Sichtlinie) komplett zum Stillstand kommen.",
    explanationKa: "აუცილებელია სრული გაჩერება 'სტოპ-ხაზთან' ან ხილვადობის ხაზთან."
  },
  {
    id: '9',
    category: 'technical',
    points: 2,
    questionDe: "Was bedeutet eine blinkende blaue Kontrollleuchte im Cockpit?",
    questionKa: "რას ნიშნავს ლურჯი ინდიკატორი მაჩვენებელთა დაფაზე?",
    optionsDe: [
      "Das Fernlicht ist eingeschaltet.",
      "Das Abblendlicht ist eingeschaltet.",
      "Die Nebelschlussleuchte ist an."
    ],
    optionsKa: [
      "შორი განათების ფარები (Fernlicht) ჩართულია.",
      "ახლო განათების ფარები ჩართულია.",
      "უკანა ნისლის საწინააღმდეგო ფარი ჩართულია."
    ],
    correctIndices: [0],
    explanationDe: "Die blaue Leuchte zeigt immer das Fernlicht an.",
    explanationKa: "ლურჯი ფერი ყოველთვის შორ განათებაზე მიუთითებს."
  },
  {
    id: '10',
    category: 'personal',
    points: 5,
    questionDe: "Ab wie viel Promille gilt für Fahranfänger in der Probezeit absolutes Alkoholverbot?",
    questionKa: "რამდენი პრომილეა დაშვებული დამწყები მძღოლებისთვის (გამოსაცდელი ვადის დროს)?",
    optionsDe: [
      "0,0 Promille",
      "0,3 Promille",
      "0,5 Promille"
    ],
    optionsKa: [
      "0,0 პრომილე",
      "0,3 პრომილე",
      "0,5 პრომილე"
    ],
    correctIndices: [0],
    explanationDe: "In der Probezeit und für Fahrer unter 21 Jahren gilt die Null-Promille-Grenze.",
    explanationKa: "გამოსაცდელი ვადის დროს და 21 წლამდე მძღოლებისთვის ალკოჰოლის მიღება კატეგორიულად აკრძალულია."
  }
];
