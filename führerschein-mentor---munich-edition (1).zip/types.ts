
export interface Question {
  id: string;
  category: 'hazard' | 'behavior' | 'priority' | 'signs' | 'environment' | 'technical' | 'personal';
  points: number;
  questionDe: string;
  questionKa: string;
  optionsDe: string[];
  optionsKa: string[];
  correctIndices: number[];
  image?: string;
  explanationDe: string;
  explanationKa: string;
}

export interface UserProgress {
  answeredIds: string[];
  correctIds: string[];
  categoryProgress: Record<string, number>;
}

export interface ExamState {
  answers: Record<string, number[]>;
  startTime: number;
  isFinished: boolean;
}

export type Language = 'de' | 'ka';
export type ViewMode = 'home' | 'practice' | 'exam';
